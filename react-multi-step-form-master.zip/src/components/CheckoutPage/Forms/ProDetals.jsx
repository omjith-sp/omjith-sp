import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { InputField, CheckboxField, SelectField } from '../../FormFields';

const qualification = [
  {
    value: undefined,
    label: 'None'
  },
  {
    value: '1',
    label: 'BTech'
  },
  {
    value: '2',
    label: 'MTech'
  },
  {
    value: '3',
    label: 'MBA'
  }
];

export default function ProDetails(props) {
    
    
  const {
    formField: {
        exp,
        designation,
        csalary,
        esalary,
        currentEmp,
        qualifications,
        skillSet,
        skype,
        linkedIn
    }
  } = props;
  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <InputField name={exp.name} label={exp.label} fullWidth />
        </Grid>
        <Grid item xs={12} sm={6}>
          <InputField name={designation.name} label={designation.label} fullWidth />
        </Grid>
        <Grid item xs={12}>
          <InputField name={csalary.name} label={csalary.label} fullWidth />
        </Grid>
        <Grid item xs={12}>
          <InputField name={esalary.name} label={esalary.label} fullWidth />
        </Grid>
        <Grid item xs={12} sm={6}>
        <InputField name={currentEmp.name} label={currentEmp.label} fullWidth />
        </Grid>
        <Grid item xs={12} sm={6}>
          <SelectField
            value={qualification.value}
            label={qualification.label}
            data={qualifications}
            fullWidth
          />
        </Grid>
        <Grid item xs={12} sm={12}>
        <InputField name={skillSet.name} label={skillSet.label} fullWidth />  
        </Grid>
        <Grid item xs={12} sm={6}>
        <InputField name={skype.name} label={skype.label} fullWidth />  
        </Grid>
        <Grid item xs={12} sm={6}>
        <InputField name={linkedIn.name} label={linkedIn.label} fullWidth />  
        </Grid>
        
      </Grid>
    </React.Fragment>
  );
}
