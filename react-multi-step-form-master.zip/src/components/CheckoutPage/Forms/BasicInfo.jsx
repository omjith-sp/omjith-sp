import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { InputField, CheckboxField, SelectField } from '../../FormFields';

export default function BasicInfo(props) {
    
  const {
    formField: {
        firstName,
        lastName,
        email,
        mobile,
        phone,
        profile,
        
    }
  } = props;
  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <InputField name={firstName.name} label={firstName.label} fullWidth />
        </Grid>
        <Grid item xs={12} sm={6}>
          <InputField name={lastName.name} label={lastName.label} fullWidth />
        </Grid>
        <Grid item xs={12}sm={6}>
          <InputField name={email.name} label={email.label} fullWidth />
        </Grid>
        <Grid item xs={12}sm={6}>
          <InputField name={mobile.name} label={mobile.label} fullWidth />
        </Grid>
        <Grid item xs={12} sm={6}>
        <InputField name={phone.name} label={phone.label} fullWidth />
        </Grid>
        <Grid item item xs={12}>
          <div>
          <InputField name={profile.name} label={profile.label} fullWidth /> 
          <button>Upload Profile Picture</button>
          <p  className="title">Uploaded Profile_Pic.png</p>
          </div>
        </Grid>
        
        {/* <Grid item xs={12} sm={6}>
          <InputField name={zipcode.name} label={zipcode.label} fullWidth />
        </Grid>
        <Grid item xs={12} sm={6}>
          <SelectField
            name={country.name}
            label={country.label}
            data={countries}
            fullWidth
          />
        </Grid>
        <Grid item xs={12}>
          <CheckboxField
            name={useAddressForPaymentDetails.name}
            label={useAddressForPaymentDetails.label}
          />
        </Grid> */}
      </Grid>
    </React.Fragment>
  );
}
