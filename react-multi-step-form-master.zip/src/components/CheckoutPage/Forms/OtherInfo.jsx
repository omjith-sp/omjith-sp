import React from 'react';
import { Grid, Typography } from '@material-ui/core';
import { InputField, CheckboxField, SelectField } from '../../FormFields';

const candidateStatus = [
  {
    value: undefined,
    label: 'None'
  },
  {
    value: '11',
    label: 'Student'
  },
  {
    value: '22',
    label: 'Professional'
  }
];

const source = [
  {
    value: null,
    label: 'None'
  },
  {
    value: '111',
    label: 'LinkedIn'
  },
  {
    value: '222',
    label: 'Discord'
  }
];

export default function ProDetails(props) {
   
  const {
    formField: {
        candidateStatus,
        source,
        cv
    }
  } = props;
  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        
      </Typography>
      <Grid container spacing={3}>       
        <Grid item xs={12} sm={6}>
          <SelectField
            name={candidateStatus.name}
            label={candidateStatus.label}
            data={candidateStatus}
            fullWidth
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <SelectField
            name={source.name}
            label={source.label}
            data={source}
            fullWidth
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <InputField name={cv.name} label={cv.label} fullWidth />
        </Grid>
      </Grid>
    </React.Fragment>
  );
}
