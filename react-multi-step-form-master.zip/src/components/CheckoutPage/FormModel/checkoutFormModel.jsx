import React, { useState } from 'react';

export default {
  formId: 'checkoutForm',
  formField: {
    firstName: {
      name: 'firstName',
      label: 'First name*',
      requiredErrorMsg: 'First name is required'
    },
    lastName: {
      name: 'lastName',
      label: 'Last name*',
      requiredErrorMsg: 'Last name is required'
    },
    email: {
      name: 'email',
      label: 'Email',
      requiredErrorMsg: 'Email is required'
    },
    mobile: {
      name: 'mobile',
      label: 'Mobile'
    },
    phone: {
      name: 'phone',
      label: 'Phone(Optional)',
    },
    profile: {
      name: 'profileImg',
      label: 'Profile Image'
    },
    street: {
        name: 'street',
        label: 'Street',
    },
    city: {
        name: 'city',
        label: 'City',
    },
    state: {
        name: 'state',
        label: 'State/Province',
    },
    zipcode: {
      name: 'zipcode',
      label: 'Zipcode*',
      requiredErrorMsg: 'Zipcode is required',
      invalidErrorMsg: 'Zipcode is not valid (e.g. 70000)'
    },
    country: {
      name: 'country',
      label: 'Country*',
      requiredErrorMsg: 'Country is required'
    },
    exp: {
        name: 'exp',
        label: 'Experience in Years'
    },
    designation: {
        name: 'designation',
        label: 'Current Designation'
    },
    csalary: {
        name: 'csalary',
        label: 'Current Salary(LPA)'
    },
    esalary: {
        name: 'esalary',
        label: 'Expected Salary(LPA)'
    },
    currentEmp: {
        name: 'currentEmp',
        label: 'Current Employer'
    },
    qualification: {
        name: 'qualification',
        label: 'Highest Qualification'
    },
    skillSet: {
        name: 'skillSet',
        label: 'Skill Set'
    },
    skype: {
        name: 'skype',
        label: 'Skype ID'
    },
    linkedIn: {
        name: 'linkedIn',
        label: 'LinkedIn'
    },
    candidateStatus:{
        name:'candidateStatus',
        label:'-Select-'

    },
    source: {
        name: 'source',
        label: 'LinkedIn'
    },
    cv: {
        name: 'cv',
        label: 'Attach CV'
    },
  }
};
