import * as Yup from 'yup';
import moment from 'moment';
import checkoutFormModel from './checkoutFormModel';
const {
  formField: {
    firstName,
    lastName,
    email,
    mobile,
    phone,
    profile,
    street,
    city,
    state,
    zipcode,
    country,
    exp,
    designation,
    csalary,
    esalary,
    currentEmp,
    qualification,
    skillSet,
    skype,
    linkedIn,
    candidateStatus,
    source,
    cv
  }
} = checkoutFormModel;

const visaRegEx = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;

export default [
  Yup.object().shape({
    [firstName.name]: Yup.string().required(`${firstName.requiredErrorMsg}`),
    [lastName.name]: Yup.string().required(`${lastName.requiredErrorMsg}`),
    [email.name]: Yup.string().required(`${email.requiredErrorMsg}`),
    [mobile.name]: Yup.string().required(`${mobile.requiredErrorMsg}`),
    [phone.name]: Yup.string().required(`${phone.requiredErrorMsg}`),
    [profile.name]: Yup.string().required(`${profile.requiredErrorMsg}`),
    [street.name]: Yup.string().required(`${street.requiredErrorMsg}`),
    [state.name]: Yup.string().required(`${state.requiredErrorMsg}`),
    [exp.name]: Yup.string().required(`${exp.requiredErrorMsg}`),
    [designation.name]: Yup.string().required(`${designation.requiredErrorMsg}`),
    [csalary.name]: Yup.string().required(`${csalary.requiredErrorMsg}`),
    [esalary.name]: Yup.string().required(`${esalary.requiredErrorMsg}`),
    [currentEmp.name]: Yup.string().required(`${currentEmp.requiredErrorMsg}`),
    [qualification.name]: Yup.string().required(`${qualification.requiredErrorMsg}`),
    [skillSet.name]: Yup.string().required(`${skillSet.requiredErrorMsg}`),
    [skype.name]: Yup.string().required(`${skype.requiredErrorMsg}`),
    [linkedIn.name]: Yup.string().required(`${linkedIn.requiredErrorMsg}`),
    [candidateStatus.name]: Yup.string().required(`${candidateStatus.requiredErrorMsg}`),
    [source.name]: Yup.string().required(`${source.requiredErrorMsg}`),
    [cv.name]: Yup.string().required(`${cv.requiredErrorMsg}`),

    [city.name]: Yup.string()
      .nullable()
      .required(`${city.requiredErrorMsg}`),
    [zipcode.name]: Yup.string()
      .required(`${zipcode.requiredErrorMsg}`)
      .test(
        'len',
        `${zipcode.invalidErrorMsg}`,
        val => val && val.length === 5
      ),
    [country.name]: Yup.string()
      .nullable()
      .required(`${country.requiredErrorMsg}`)
    
  }),
  // Yup.object().shape({
  //   [nameOnCard.name]: Yup.string().required(`${nameOnCard.requiredErrorMsg}`),
  //   [cardNumber.name]: Yup.string()
  //     .required(`${cardNumber.requiredErrorMsg}`)
  //     .matches(visaRegEx, cardNumber.invalidErrorMsg),
  //   [expiryDate.name]: Yup.string()
  //     .nullable()
  //     .required(`${expiryDate.requiredErrorMsg}`)
  //     .test('expDate', expiryDate.invalidErrorMsg, val => {
  //       if (val) {
  //         const startDate = new Date();
  //         const endDate = new Date(2050, 12, 31);
  //         if (moment(val, moment.ISO_8601).isValid()) {
  //           return moment(val).isBetween(startDate, endDate);
  //         }
  //         return false;
  //       }
  //       return false;
  //     }),
  //   [cvv.name]: Yup.string()
  //     .required(`${cvv.requiredErrorMsg}`)
  //     .test('len', `${cvv.invalidErrorMsg}`, val => val && val.length === 3)
  // })
];
