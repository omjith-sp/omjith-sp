import checkoutFormModel from './checkoutFormModel';
import React from "react";
//import formField from "./formField";
const {
    formField: {
      firstName,
      lastName,
      email,
      mobile,
      phone,
      profile,
      street,
      city,
      state,
      zipcode,
      country,
      exp,
      designation,
      csalary,
      esalary,
      currentEmp,
      qualification,
      skillSet,
      skype,
      linkedIn,
      candidateStatus,
      source,
      cv
      
    }
  } = checkoutFormModel;
  
  export default {
    [firstName.name]: '  ',
    [lastName.name]: ' ',
    [email.name]: ' ',
    [mobile.name]: ' ',
    [phone.name]: ' ',
    [profile.name]: ' ',
    [street.name]: ' ',
    [city.name]: ' ',
    [state.name]: ' ',
    [zipcode.name]: ' ',
    [country.name]: ' ',
    [exp.name]: '  ',
    [designation.name]: ' ',
    [csalary.name]: ' ',
    [esalary.name]:' ',
    [currentEmp.name]:' ',
    [qualification.name]:' ',
    [skillSet.name]:' ',
    [skype.name]:' ',
    [linkedIn.name]:' ',
    [candidateStatus.name]:' ',
    [source.name]:' ',
    [cv.name]:' '
  };
  
